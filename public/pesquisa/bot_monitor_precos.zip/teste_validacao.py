"""
Script de teste unitário e validação de regras de negócio para o Bot de Monitoramento.
Testa:
1. Leitura de config.json e expiração de data_limite.
2. Persistência no CSV nativo e análise de variação de preços (queda, subida, recorde).
3. Respeito ao intervalo de frequencia_horas.
4. Geração do gráfico estilizado com Matplotlib.
"""

from datetime import datetime, date, timedelta
from pathlib import Path
import tempfile

from monitor import (
    carregar_configuracao,
    verificar_expiracao,
    deve_executar,
    analisar_historico_preco,
    gerar_grafico_historico,
    salvar_registro_csv,
    ScrapedItem,
)


def testar_config_e_expiracao():
    print("[1/4] Testando carregamento de config e expiração...")
    config = carregar_configuracao()
    assert "produtos" in config and len(config["produtos"]) > 0

    hoje = date(2026, 9, 20)
    produto_valido = {"data_limite": "2026-12-31", "nome_produto": "Teste Valido"}
    produto_expirado = {"data_limite": "2026-09-01", "nome_produto": "Teste Expirado"}
    produto_hoje = {"data_limite": "2026-09-20", "nome_produto": "Teste Hoje"}

    assert not verificar_expiracao(produto_valido, hoje), "Produto com data futura não deve expirar"
    assert verificar_expiracao(produto_expirado, hoje), "Produto com data passada deve expirar"
    assert not verificar_expiracao(produto_hoje, hoje), "Produto com data limite de hoje ainda está no prazo"
    print("  -> Sucesso: Todas as validações de data_limite passaram!")


def testar_analise_preco_e_csv():
    print("[2/4] Testando persistência em CSV e análise de histórico de preços...")
    with tempfile.TemporaryDirectory() as tmpdir:
        csv_path = Path(tmpdir) / "teste_historico.csv"
        agora = datetime.now()

        item1 = ScrapedItem("Item Teste", 100.0, "https://exemplo.com/1", "Mercado Livre")
        salvar_registro_csv(item1, "Produto X", agora - timedelta(days=2), csv_path)

        item2 = ScrapedItem("Item Teste", 90.0, "https://exemplo.com/2", "Mercado Livre")
        salvar_registro_csv(item2, "Produto X", agora - timedelta(days=1), csv_path)

        eh_menor, texto = analisar_historico_preco("Produto X", 80.0, csv_path)
        assert eh_menor, "80.0 deve ser considerado o menor histórico"
        assert "RECORDE" in texto
        assert "Queda de R$ 10.00" in texto

        eh_menor_2, texto_2 = analisar_historico_preco("Produto X", 95.0, csv_path)
        assert not eh_menor_2, "95.0 não é o menor histórico"
        assert "Subiu R$ 5.00" in texto_2
    print("  -> Sucesso: Cálculos de variação e menor histórico validados!")


def testar_regra_frequencia():
    print("[3/4] Testando regra de frequencia_horas...")
    with tempfile.TemporaryDirectory() as tmpdir:
        csv_path = Path(tmpdir) / "historico_freq.csv"
        agora = datetime.now()

        item = ScrapedItem("Item Freq", 50.0, "https://exemplo.com", "Shopee")
        # Registra última verificação há 2 horas
        salvar_registro_csv(item, "Produto Freq", agora - timedelta(hours=2), csv_path)

        # Produto com frequencia de 4 horas
        produto = {"nome_produto": "Produto Freq", "frequencia_horas": 4, "ativo": True}

        # Com force=False e intervalo de 4h, não deve rodar
        assert not deve_executar(produto, agora, force=False, csv_path=csv_path), "Não deve executar se passaram menos de 4h"

        # Com force=True, deve rodar imediatamente
        assert deve_executar(produto, agora, force=True, csv_path=csv_path), "Deve executar com a flag --force ativada"
    print("  -> Sucesso: Regra de frequência respeitada corretamente!")


def testar_geracao_grafico():
    print("[4/4] Testando geração de gráfico Matplotlib (Dark Mode)...")
    with tempfile.TemporaryDirectory() as tmpdir:
        csv_path = Path(tmpdir) / "teste_historico.csv"
        graficos_dir = Path(tmpdir) / "graficos"
        agora = datetime.now()

        # Insere histórico com variação de preços
        precos_amostra = [119.90, 115.00, 99.90, 105.00, 89.90]
        for i, p in enumerate(precos_amostra):
            item = ScrapedItem("Item Teste", p, "https://exemplo.com", "Mercado Livre")
            salvar_registro_csv(
                item, "Filamento PETG 1kg", agora - timedelta(hours=(5 - i) * 4), csv_path
            )

        caminho_grafico = gerar_grafico_historico("Filamento PETG 1kg", csv_path, graficos_dir)
        assert caminho_grafico is not None, "O arquivo de gráfico deve ser retornado"
        assert caminho_grafico.exists(), "O arquivo de imagem deve existir no disco"
        assert caminho_grafico.stat().st_size > 5000, "O gráfico gerado deve ter tamanho de imagem válido"
    print(f"  -> Sucesso: Gráfico gerado perfeitamente! ({caminho_grafico.name})")


if __name__ == "__main__":
    print("=== INICIANDO BATERIA DE TESTES DO BOT DE PREÇOS ===")
    testar_config_e_expiracao()
    testar_analise_preco_e_csv()
    testar_regra_frequencia()
    testar_geracao_grafico()
    print("\n=======================================================")
    print("  >>> TODOS OS TESTES PASSARAM COM 100% DE SUCESSO! <<<")
    print("=======================================================")
