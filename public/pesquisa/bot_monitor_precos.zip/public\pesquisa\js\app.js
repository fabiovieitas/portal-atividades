/**
 * app.js
 * Orquestrador da interface moderna, limpa e amigável do LabKids Ofertas.
 * Inclui Quick-Add estilo MeliAlerta, persistência 100% local (anti-F5) e conversão de afiliados.
 */

let appState = {
  config: { produtos: [] },
  historico: [],
  produtoSelecionado: null
};

document.addEventListener('DOMContentLoaded', async () => {
  configurarEventosHero();
  await recarregarDados();
});

// 1. EVENTOS DA BARRA HERO QUICK-ADD
function configurarEventosHero() {
  const inputUrl = document.getElementById('inputQuickUrl');
  const indicator = document.getElementById('platformIndicator');

  if (!inputUrl) return;

  inputUrl.addEventListener('input', () => {
    const val = inputUrl.value.trim().toLowerCase();
    if (val.includes('mercadolivre.com') || val.includes('mercadolibre.com')) {
      indicator.className = 'platform-indicator ml';
      indicator.innerHTML = '🟡 Mercado Livre';
    } else if (val.includes('shopee.com')) {
      indicator.className = 'platform-indicator shopee';
      indicator.innerHTML = '🟠 Shopee';
    } else {
      indicator.className = 'platform-indicator';
      indicator.innerHTML = '🔗 Automático';
    }
  });

  inputUrl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      adicionarProdutoRapido();
    }
  });
}

// 2. ADIÇÃO RÁPIDA DE PRODUTO
async function adicionarProdutoRapido() {
  const inputUrl = document.getElementById('inputQuickUrl');
  const btn = document.getElementById('btnQuickAdd');
  const url = inputUrl.value.trim();

  if (!url || !url.startsWith('http')) {
    mostrarToast('Por favor, cole um link válido do Mercado Livre ou Shopee.', 'error');
    return;
  }

  btn.disabled = true;
  btn.innerHTML = '⏳ Rastreando...';

  // Identifica nome amigável a partir da URL
  let nomeAmigavel = extrairNomeDeUrl(url);
  const isMeli = url.includes('mercadolivre.com') || url.includes('mercadolibre.com');
  const plataforma = isMeli ? 'Mercado Livre' : 'Shopee';

  const novoProduto = {
    nome_produto: nomeAmigavel,
    url_pesquisa: url,
    frequencia_horas: 4,
    data_limite: '2026-12-31',
    ativo: true,
    plataforma: plataforma
  };

  // 1. Salva imediatamente no estado e localStorage (anti-perda F5)
  appState.config.produtos.unshift(novoProduto);
  await GitHubSync.salvarConfig(appState.config);

  // 2. Tenta extrair o preço atual em tempo real
  try {
    const res = await fetch('/api/pesquisa/obter-preco', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: url })
    });
    if (res.ok) {
      const data = await res.json();
      if (data && data.preco) {
        if (data.titulo) novoProduto.nome_produto = data.titulo;
        appState.historico.push({
          data_hora: new Date().toISOString().replace('T', ' ').substring(0, 19),
          nome_produto: novoProduto.nome_produto,
          preco: data.preco,
          link_produto: data.link || url,
          plataforma: plataforma
        });
        await GitHubSync.salvarConfig(appState.config);
      }
    }
  } catch (e) {}

  inputUrl.value = '';
  document.getElementById('platformIndicator').className = 'platform-indicator';
  document.getElementById('platformIndicator').innerHTML = '🔗 Automático';
  btn.disabled = false;
  btn.innerHTML = '⚡ Rastrear Oferta';

  renderizarCardsProdutos();
  popularSeletorGrafico();
  mostrarToast(`"${novoProduto.nome_produto}" adicionado com sucesso!`, 'success');
}

function extrairNomeDeUrl(url) {
  try {
    const u = new URL(url);
    const pathParts = u.pathname.split('/').filter(p => p && !p.startsWith('MLB') && p !== 'p' && p !== 'up');
    if (pathParts.length > 0) {
      const slug = pathParts[0].replace(/-/g, ' ');
      return slug.charAt(0).toUpperCase() + slug.slice(1);
    }
  } catch (e) {}
  return 'Produto Monitorado';
}

// 3. CARREGAR DADOS E ATUALIZAR INTERFACE
async function recarregarDados() {
  try {
    appState.config = await GitHubSync.carregarConfig();
    appState.historico = await GitHubSync.carregarHistoricoCsv();

    renderizarCardsProdutos();
    popularSeletorGrafico();
    renderizarVisualizacaoGrafico();
  } catch (err) {
    console.error(err);
    mostrarToast('Erro ao sincronizar dados: ' + err.message, 'error');
  }
}

// 4. RENDERIZAR CARDS DE PRODUTOS LIMPOS E MODERNOS
function renderizarCardsProdutos() {
  const container = document.getElementById('productsGrid');
  if (!container) return;

  const produtos = appState.config.produtos || [];
  if (produtos.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--text-muted); background: var(--bg-card); border-radius: var(--radius-md); border: 1px dashed var(--border-color);">
        <p style="font-size: 16px; margin-bottom: 8px;">Nenhum produto monitorado ainda.</p>
        <p style="font-size: 13px;">Cole qualquer link do Mercado Livre ou Shopee acima para começar!</p>
      </div>
    `;
    return;
  }

  container.innerHTML = '';
  produtos.forEach((prod, index) => {
    // Localiza histórico do produto
    const registros = appState.historico.filter(h => 
      h.nome_produto.toLowerCase() === prod.nome_produto.toLowerCase()
    ).sort((a, b) => new Date(b.data_hora) - new Date(a.data_hora));

    const ultimoPreco = registros[0] ? registros[0].preco : null;
    const menorPreco = registros.length > 0 ? Math.min(...registros.map(r => r.preco)) : null;
    const linkReal = registros[0]?.link_produto || prod.url_pesquisa;

    const isMeli = prod.url_pesquisa.includes('mercadolivre.com') || prod.url_pesquisa.includes('mercadolibre.com');
    const badgeClass = isMeli ? 'ml' : 'shopee';
    const badgeText = isMeli ? '🟡 Mercado Livre' : '🟠 Shopee';

    // Conversão automática para Link de Afiliado MeLi Mais / Shopee
    const linkAfiliado = AffiliateManager.converter(linkReal, isMeli ? 'Mercado Livre' : 'Shopee');

    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
      <div>
        <div class="product-card-top">
          <span class="platform-badge ${badgeClass}">${badgeText}</span>
          <span style="font-size: 11px; color: var(--text-muted);">${registros[0] ? 'Hoje às ' + registros[0].data_hora.split(' ')[1] : 'Monitorando'}</span>
        </div>
        <h4 class="product-card-title" title="${prod.nome_produto}">${prod.nome_produto}</h4>
      </div>

      <div>
        <div class="product-price-section">
          <div>
            <div class="current-price-label">Melhor Preço Atual</div>
            <div class="current-price-value">${ultimoPreco ? 'R$ ' + ultimoPreco.toFixed(2).replace('.', ',') : 'Rastreando...'}</div>
          </div>
          ${menorPreco ? `<div class="lowest-badge">⭐ R$ ${menorPreco.toFixed(2).replace('.', ',')}</div>` : ''}
        </div>

        <div class="product-actions">
          <a href="${linkAfiliado}" target="_blank" rel="noopener noreferrer" class="btn-buy">
            🛒 Ver Menor Oferta ↗
          </a>
          <button class="btn-icon" onclick="selecionarProdutoGrafico('${prod.nome_produto}')" title="Ver Gráfico Histórico">
            📈
          </button>
          <button class="btn-icon danger" onclick="excluirProduto(${index})" title="Remover Produto">
            🗑️
          </button>
        </div>
      </div>
    `;

    container.appendChild(card);
  });
}

// 5. SELETOR E EXIBIÇÃO DE GRÁFICOS
function popularSeletorGrafico() {
  const select = document.getElementById('selectProdutoGrafico');
  if (!select) return;

  const produtos = appState.config.produtos || [];
  select.innerHTML = '';

  if (produtos.length === 0) {
    select.innerHTML = '<option value="">Nenhum produto</option>';
    return;
  }

  produtos.forEach((prod, i) => {
    const opt = document.createElement('option');
    opt.value = prod.nome_produto;
    opt.textContent = prod.nome_produto;
    if (i === 0 && !appState.produtoSelecionado) {
      appState.produtoSelecionado = prod.nome_produto;
    }
    select.appendChild(opt);
  });

  if (appState.produtoSelecionado) {
    select.value = appState.produtoSelecionado;
  }

  select.onchange = (e) => {
    appState.produtoSelecionado = e.target.value;
    renderizarVisualizacaoGrafico();
  };
}

function selecionarProdutoGrafico(nomeProduto) {
  appState.produtoSelecionado = nomeProduto;
  const select = document.getElementById('selectProdutoGrafico');
  if (select) select.value = nomeProduto;
  renderizarVisualizacaoGrafico();

  const secao = document.getElementById('secaoGrafico');
  if (secao) secao.scrollIntoView({ behavior: 'smooth' });
}

function renderizarVisualizacaoGrafico() {
  if (!appState.produtoSelecionado) return;
  const registros = appState.historico.filter(h => 
    h.nome_produto.toLowerCase() === appState.produtoSelecionado.toLowerCase()
  );

  ChartsModule.renderizarGrafico('priceChart', registros, appState.produtoSelecionado);
}

// 6. EXCLUSÃO COM PERSISTÊNCIA 100% GARANTIDA (ANTI-F5)
async function excluirProduto(index) {
  const prod = appState.config.produtos[index];
  if (!prod) return;

  if (!confirm(`Deseja parar de monitorar "${prod.nome_produto}"?`)) return;

  appState.config.produtos.splice(index, 1);
  await GitHubSync.salvarConfig(appState.config);

  renderizarCardsProdutos();
  popularSeletorGrafico();
  renderizarVisualizacaoGrafico();
  mostrarToast('Produto removido com sucesso!', 'info');
}

// 7. MODAL DE AFILIADOS & MONETIZAÇÃO
function abrirModalAfiliado() {
  document.getElementById('afiliadoMeliInput').value = AffiliateManager.getMeliTag();
  document.getElementById('afiliadoShopeeInput').value = AffiliateManager.getShopeeTag();
  document.getElementById('modalAfiliado').classList.add('active');
}

function fecharModalAfiliado() {
  document.getElementById('modalAfiliado').classList.remove('active');
}

function salvarConfigAfiliado() {
  const meliTag = document.getElementById('afiliadoMeliInput').value;
  const shopeeTag = document.getElementById('afiliadoShopeeInput').value;

  AffiliateManager.setMeliTag(meliTag);
  AffiliateManager.setShopeeTag(shopeeTag);

  fecharModalAfiliado();
  renderizarCardsProdutos(); // Atualiza os links gerados
  mostrarToast('Configurações de afiliado salvas com sucesso!', 'success');
}

// 8. DISPARO MANUAL DE VARREDURA
async function dispararVarredura() {
  mostrarToast('Iniciando checagem de preços nos marketplaces...', 'info');
  try {
    await GitHubSync.dispararExecucaoManual();
    mostrarToast('Varredura em andamento! Atualizando histórico...', 'success');

    let contador = 0;
    const lenAnterior = appState.historico.length;
    const polling = setInterval(async () => {
      contador++;
      try {
        const dados = await GitHubSync.carregarHistoricoCsv();
        if (dados && dados.length > lenAnterior) {
          clearInterval(polling);
          await recarregarDados();
          mostrarToast('Novos preços atualizados no histórico e gráficos!', 'success');
        }
      } catch (e) {}
      if (contador >= 10) clearInterval(polling);
    }, 4000);
  } catch (err) {
    mostrarToast(err.message, 'error');
  }
}

// 9. TOASTS
function mostrarToast(mensagem, tipo = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'toast';
  if (tipo === 'error') toast.style.borderLeftColor = 'var(--accent-rose)';
  if (tipo === 'success') toast.style.borderLeftColor = 'var(--accent-green)';

  toast.textContent = mensagem;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
