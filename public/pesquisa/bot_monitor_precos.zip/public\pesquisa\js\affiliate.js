/**
 * affiliate.js
 * Utilitário de conversão para links compartilháveis / afiliados (Mercado Livre e Shopee).
 * Permite ao dono da plataforma monetizar todos os cliques de qualquer usuário.
 */

const AffiliateManager = {
  STORAGE_KEY_MELI: 'affiliate_meli_tag',
  STORAGE_KEY_SHOPEE: 'affiliate_shopee_tag',

  getMeliTag() {
    return localStorage.getItem(this.STORAGE_KEY_MELI) || 'labkids-20';
  },

  setMeliTag(tag) {
    localStorage.setItem(this.STORAGE_KEY_MELI, tag.trim());
  },

  getShopeeTag() {
    return localStorage.getItem(this.STORAGE_KEY_SHOPEE) || 'labkids';
  },

  setShopeeTag(tag) {
    localStorage.setItem(this.STORAGE_KEY_SHOPEE, tag.trim());
  },

  /**
   * Converte qualquer URL para o link compartilhável com a tag de afiliado do dono.
   */
  converter(url, plataforma = '') {
    if (!url || typeof url !== 'string') return '#';
    const uStr = url.trim();

    const isMeli = plataforma === 'Mercado Livre' || 
                   uStr.includes('mercadolivre.com') || 
                   uStr.includes('mercadolibre.com');

    const isShopee = plataforma === 'Shopee' || 
                     uStr.includes('shopee.com');

    // 1. MERCADO LIVRE
    if (isMeli) {
      const tag = this.getMeliTag();
      try {
        const u = new URL(uStr);
        u.searchParams.delete('tracking_id');
        u.searchParams.delete('matt_tool');
        u.searchParams.delete('matt_word');
        u.searchParams.delete('af_sub1');

        if (tag) {
          u.searchParams.set('matt_tool', tag);
          u.searchParams.set('tracking_id', tag);
          u.searchParams.set('af_sub1', 'labkids');
        }
        return u.toString();
      } catch (e) {
        return uStr;
      }
    }

    // 2. SHOPEE
    if (isShopee) {
      const tag = this.getShopeeTag();
      try {
        const u = new URL(uStr);
        u.searchParams.delete('af_siteid');
        u.searchParams.delete('af_sub_siteid');

        if (tag) {
          u.searchParams.set('af_siteid', tag);
          u.searchParams.set('af_sub_siteid', 'labkids');
        }
        return u.toString();
      } catch (e) {
        return uStr;
      }
    }

    return uStr;
  }
};
