# 🤖 Bot & Painel de Monitoramento de Preços — LabKids

Uma solução completa de ponta a ponta com **Automação em Python**, **Scraping Resiliente** e **Painel Web Interativo (SPA)** pronto para deploy no subdomínio **`pesquisa.labkids.online`** via Vercel.

---

## 🌐 Painel Web: `pesquisa.labkids.online`

O projeto inclui um **Dashboard Web Completo** em Dark Mode e Glassmorphism para você:
* 📊 **Visualizar Gráficos Interativos**: Gráficos dinâmicos com **Chart.js** exibindo a evolução temporal e o menor preço histórico.
* ⚙️ **Gerenciar Produtos**: Adicionar, editar, pausar/ativar e excluir produtos do monitoramento sem tocar em código.
* ⚡ **Disparo com 1 Clique**: Botão *"Verificar Preços Agora"* para acionar o robô no GitHub Actions instantaneamente direto pelo site.
* 🔗 **Comprar Rápido**: Links diretos para os produtos com o menor preço encontrado no Mercado Livre e Shopee.

---

## 📁 Estrutura do Projeto

```text
bot_monitor_precos/
├── public/                       # Frontend Web (pesquisa.labkids.online)
│   ├── index.html                # Aplicação SPA moderna
│   ├── css/
│   │   └── style.css             # Estilos Dark Mode & Glassmorphism
│   └── js/
│       ├── app.js                # Lógica de interface e gerenciamento de produtos
│       ├── charts.js             # Gráficos interativos com Chart.js
│       └── github_sync.js        # Integração em tempo real com a API do GitHub
├── vercel.json                   # Configuração de deploy para a Vercel
├── .github/
│   └── workflows/
│       └── agendador.yml          # Automação agendada (Cron) e commit de dados
├── config.json                    # Cadastro de produtos e configurações
├── monitor.py                     # Script orquestrador de scraping em Python
├── scrapers/                      # Scrapers desacoplados (Mercado Livre & Shopee)
│   ├── base.py
│   ├── mercadolivre.py
│   └── shopee.py
├── historico_precos.csv          # Histórico acumulado de verificações
├── graficos/                     # Imagens dos gráficos gerados
├── requirements.txt              # Dependências Python
└── README.md                      # Manual completo
```

---

## 🚀 Publicando no Subdomínio `pesquisa.labkids.online` (Vercel)

Como o seu domínio `labkids.online` já está na Vercel (`portal-atividades.vercel.app`), o processo de publicação leva menos de 2 minutos:

### Passo 1: Criar o Projeto na Vercel
1. Acesse o seu painel na **[Vercel](https://vercel.com/)**.
2. Clique em **Add New...** ➔ **Project**.
3. Importe o repositório do **`bot_monitor_precos`** do seu GitHub.
4. Mantenha as configurações padrão (Framework Preset: *Other*) e clique em **Deploy**.

### Passo 2: Configurar o Subdomínio `pesquisa.labkids.online`
1. No painel do projeto recém-criado na Vercel, vá em **Settings** ➔ **Domains**.
2. No campo de domínio, digite: **`pesquisa.labkids.online`** e clique em **Add**.
3. A Vercel exibirá o apontamento DNS necessário:
   * **Tipo**: `CNAME`
   * **Nome / Host**: `pesquisa`
   * **Valor / Destino**: `cname.vercel-dns.com`
4. Acesse o painel onde você gerencia o DNS do `labkids.online` (ex: Cloudflare, Registro.br ou Hostinger) e adicione esse registro `CNAME`.
5. Em poucos minutos o certificado SSL será emitido e seu painel estará no ar em **`https://pesquisa.labkids.online`**!

---

## 🔑 Sincronização em Tempo Real (Painel ➔ GitHub)

Para que o painel web consiga salvar as alterações de produtos diretamente no repositório e acionar o botão *"Verificar Preços Agora"*:
1. Abra o painel web em `https://pesquisa.labkids.online` (ou localmente).
2. Acesse a aba **🔑 Conexão GitHub & Nuvem**.
3. Informe o seu repositório (ex: `seu-usuario/bot_monitor_precos`).
4. Cole um **Personal Access Token** do GitHub (gerado em *GitHub ➔ Settings ➔ Developer settings ➔ Personal access tokens* com escopo `repo` e `workflow`).
5. Clique em **Salvar Conexão**. *(Os dados ficam salvos de forma segura no localStorage do seu navegador)*.


---

## ⚙️ 1. Como Funciona o `config.json`

O arquivo `config.json` permite cadastrar e gerenciar quantos produtos você desejar.

```json
{
  "produtos": [
    {
      "nome_produto": "Filamento PETG 1kg Preto",
      "url_pesquisa": "https://lista.mercadolivre.com.br/filamento-petg-1kg-preto_OrderId_PRICE_ASC_CustoEnvio_Gratis_NoIndex_True",
      "frequencia_horas": 4,
      "data_limite": "2026-12-31",
      "ativo": true
    },
    {
      "nome_produto": "Mouse Sem Fio Recarregável",
      "url_pesquisa": "https://shopee.com.br/search?keyword=mouse%20sem%20fio%20recarregavel&sortBy=price&order=asc",
      "frequencia_horas": 8,
      "data_limite": "2026-12-31",
      "ativo": true
    }
  ]
}
```

### Explicação dos Campos:
* **`nome_produto`**: Identificador amigável do produto que aparecerá nas notificações e no título do gráfico.
* **`url_pesquisa`**: Link de busca copiado do seu navegador com todos os filtros aplicados (ex: Preço Crescente, Frete Grátis, Full, Vendedor Nacional).
* **`frequencia_horas`**: Intervalo mínimo entre checagens em horas. Se o GitHub Actions rodar a cada 2h e seu produto estiver configurado para `4h`, ele só consultará quando 4h tiverem se passado desde a última checagem.
* **`data_limite`**: Data de expiração no formato `AAAA-MM-DD`. Se a data atual for maior que essa data:
  1. A pesquisa é ignorada.
  2. Um aviso de expiração é enviado ao Telegram.
  3. O campo `"ativo"` é automaticamente alterado para `false` no `config.json`.
* **`ativo`**: `true` para monitorar ou `false` para pausar manualmente.

---

## 📲 2. Configurando o Bot e o Chat ID no Telegram

Para receber as notificações no seu celular ou grupo:

### Passo 1: Criar o Bot
1. Abra o Telegram e pesquise por **`@BotFather`**.
2. Envie o comando `/newbot`.
3. Escolha um nome para o bot (ex: `Meu Monitor de Ofertas`).
4. Escolha um username que termine em `bot` (ex: `meu_monitor_ofertas_bot`).
5. O BotFather fornecerá um **Token de Acesso HTTP** parecido com:
   `7123456789:AAFlkjhsdf89234jhskdjfh23k4j`
   *(Guarde este valor como `TELEGRAM_BOT_TOKEN`)*.

### Passo 2: Obter o seu Chat ID
1. Inicie uma conversa com o seu bot recém-criado clicando no link dele e enviando qualquer mensagem (ex: `/start` ou `Olá`).
2. Agora, pesquise no Telegram pelo bot **`@userinfobot`** e dê `/start`.
3. Ele responderá com o seu **Id** numérico (ex: `123456789`).
   *(Guarde este número como `TELEGRAM_CHAT_ID`)*.
   *(Se preferir enviar para um canal ou grupo, adicione seu bot como administrador do grupo e use o ID do grupo)*.

---

## ☁️ 3. Configurando a Automação no GitHub Actions

O bot pode rodar de forma 100% autônoma na infraestrutura gratuita do GitHub, sem precisar do computador ligado.

### Passo 1: Subir o projeto para o GitHub
1. Crie um repositório no seu GitHub (pode ser **Privado**).
2. Envie todos os arquivos deste projeto para o repositório.

### Passo 2: Cadastrar as Credenciais (Secrets)
1. No seu repositório no GitHub, clique na aba **Settings** (Configurações).
2. No menu lateral esquerdo, vá em **Secrets and variables** ➔ **Actions**.
3. Clique no botão verde **New repository secret**.
4. Crie duas chaves:
   - Nome: `TELEGRAM_BOT_TOKEN` | Valor: *(cole o token do BotFather)*
   - Nome: `TELEGRAM_CHAT_ID` | Valor: *(cole o seu ID numérico)*

### Passo 3: Conceder Permissão de Escrita ao Workflow
Para que o GitHub Actions consiga atualizar o `historico_precos.csv` e salvar as imagens dos gráficos no repositório:
1. Em **Settings** do repositório, clique em **Actions** ➔ **General**.
2. Role até a seção **Workflow permissions**.
3. Selecione a opção **Read and write permissions**.
4. Marque a caixinha **Allow GitHub Actions to create and approve pull requests**.
5. Clique em **Save**.

Pronto! O GitHub Actions irá rodar automaticamente no intervalo configurado em `.github/workflows/agendador.yml`.

> 💡 **Dica de Teste:** Você pode disparar o bot manualmente a qualquer momento indo na aba **Actions** no GitHub, selecionando **Agendador de Monitoramento de Preços** e clicando em **Run workflow**.

---

## 💻 4. Executando Localmente no Computador (Opcional)

Se desejar testar ou rodar na sua máquina local:

### 1. Criar ambiente virtual e instalar dependências
```bash
python -m venv venv

# No Windows:
.\venv\Scripts\activate

# No Linux/Mac:
source venv/bin/activate

# Instalar pacotes:
pip install -r requirements.txt

# Instalar o navegador Playwright (necessário para a Shopee):
playwright install chromium
```

### 2. Configurar o arquivo `.env`
Crie um arquivo chamado `.env` na raiz do projeto com base no `.env.example`:
```env
TELEGRAM_BOT_TOKEN=seu_token_aqui
TELEGRAM_CHAT_ID=seu_chat_id_aqui
```

### 3. Rodar o monitoramento
```bash
# Execução normal (respeita a regra de frequência_horas):
python monitor.py

# Forçar verificação de todos os itens imediatamente:
python monitor.py --force
```

---

## 📊 5. Recursos e Resiliência

* **Scraper Mercado Livre**: Suporta a arquitetura tradicional e a nova arquitetura baseada em cards dinâmicos do Mercado Livre (`poly-card`), tratando centavos e descartando preços promocionais tachados.
* **Scraper Shopee**: Utiliza **Playwright Headless** com parâmetros de evasão de automação para renderizar JavaScript client-side e aguardar o carregamento dos itens reais da busca. Inclui fallback automático via API pública interna.
* **Gráficos Elegantes**: Gera gráficos em dark mode profissional destacando a data e o valor do menor preço histórico com anotação visual.
* **Auto-Gestão de Prazos**: Se uma busca ultrapassar a data de término (`data_limite`), o bot notifica você no Telegram e desativa o item automaticamente em `config.json`.
